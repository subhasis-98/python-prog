def count_word(strr):
    count = 0
    for char in strr:
        count += 1
    return count
print("Total Word is : ",count_word("Hello "))