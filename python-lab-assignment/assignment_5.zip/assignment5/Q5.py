def check_anagram(str,str1):
    count1 = 0
    count2 = len(str1)
    split1 = str.split()
    split2 = str1.split()
    for char in split1:
        for char1 in split2:
            if char == char1:
                count1 = count1 + 1
    if count1 == count2:
        print("Anagram")
    else :
        print("Not an Anagram")
str = "as"
str1 = "sa"
check_anagram(str,str1)

def Anagram(s1,s2):
    k1=0
    k2=0
    lenofsp1=0
    lenofsp2=0
    for s in s1:
        if s==' ':
            lenofsp1+=1
    for s in s2:
        if s==' ':
            lenofsp2+=1
    for s in s1:
          if s in s2 and s!=' ':
               if s1.count(s)==s2.count(s):
                    k1+=1
                    continue
               else:
                   break
          
    
    for s in s2:
               if s in s1 and s!=' ':
                   if s1.count(s)==s2.count(s):
                        k2+=1
                        continue
                   else:
                       break
    return (k1==len(s1)-lenofsp1 and k2==len(s2)-lenofsp2)                
     
s1='william shakespeare'
s2='i am a weakish speller'
s1='ea rath'
s2='hae art '

print(Anagram(s1,s2))
print(sorted(s1)==sorted(s2))