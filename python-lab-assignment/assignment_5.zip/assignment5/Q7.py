
s=' '+input()
i=0
s1=''
while i<len(s):
    if s[i]==' ':
        s1=s1+s[i]
        if ord(s[i+1])>=65 and ord(s[i+1])<=90:
            s1=s1+s[i+1]
        else:
            s1=s1+chr(ord(s[i+1])-32)
        i+=1
    else:
        s1+=s[i]
    i+=1
print(s1)