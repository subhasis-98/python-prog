x = 2
def test():
  x = x + 1
  print(x)
print(x)