str = "noon"
str1 = str[::-1]
if str == str1:
    print("Symmetric")
else :
    print("Asymmetric")